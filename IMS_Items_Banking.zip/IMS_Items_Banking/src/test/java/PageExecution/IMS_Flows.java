package PageExecution;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.ValueRange;

import BaseClassPackage.BaseClass;
import PageFactory.IMSLocator;
import io.github.bonigarcia.wdm.WebDriverManager;

public class IMS_Flows {
	public static WebDriver driver;
	public static IMSLocator lo;

public IMS_Flows(WebDriver driver) {
		this.driver=driver;
		// TODO Auto-generated constructor stub
	}

public static HashMap<String, String> getDataAsMap(int a, int b) throws GeneralSecurityException, IOException {

    NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
    String spreadsheetId = "13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
    String range = "IMS_Datasheet";
    Sheets service = new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
            .setApplicationName(APPLICATION_NAME).build();
    ValueRange response = service.spreadsheets().values().get(spreadsheetId, range).execute();

    List<List<Object>> values = response.getValues();
    HashMap<String, String> keyValueMap = new HashMap<>();

    if (values == null || values.isEmpty()) {
        System.out.println("No data found.");
    } else {
        // Iterate through each row
        for (List<Object> row : values) {
            // Ensure row has at least two columns (key and value)
            if (row.size() >= 2) {
                String key = row.get(a).toString(); // First column as key
                String value = row.get(b).toString(); // Second column as value
                keyValueMap.put(key, value);
                // System.out.println(keyValueMap);// Add to map
                // break;
            }
        }
    }
    // System.out.println(keyValueMap);
    return keyValueMap;
}

public static String getValueFromKey(String key, int a, int b) throws GeneralSecurityException, IOException {

    HashMap<String, String> keypairs = getDataAsMap(a,b);
    String value = keypairs.get(key);
    System.out.println(value);
    return value;
}

// =============================================================================================================================

	private static final String APPLICATION_NAME = "Google Sheets API";
	private static final JsonFactory JSON_FACTORY = GsonFactory.getDefaultInstance();
	private static final String TOKENS_DIRECTORY_PATH = "tokens/path";

	private static final String existingSpreadSheetID = "13gfYl2OOdykh-oXCHtrygUDYETRCI2NXa7XPKT6hQoA";
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS, SheetsScopes.DRIVE);
	private static final String CREDENTIALS_FILE_PATH = "/credentials.json";

	static Sheets.Spreadsheets spreadsheets;

	private static Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		InputStream in = SheetWriteExample.class.getResourceAsStream(CREDENTIALS_FILE_PATH);
		if (in == null) {
			throw new FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH);
		}
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
				clientSecrets, SCOPES)
				.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
				.setAccessType("offline").build();

		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();
		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public static String path = System.getProperty("user.dir");

	public static void ScreenShot(WebDriver driver, String name) {
		// Specify the folder path where you want to save the extent report
		String folderPath = path + "/Screenshot/";

		// Create folder if it doesn't exist
		File folder = new File(folderPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File src = ts.getScreenshotAs(OutputType.FILE);
			File des = new File(folderPath + name + ".png");
			FileHandler.copy(src, des);
			// System.out.println("Screenshot saved at: " + des.getAbsolutePath());
		} catch (IOException e) {
			// e.printStackTrace();
			System.err.println("Error occurred while taking a screenshot: " + e.getMessage());
		}
	}
	
//	public static void main(String[] args) throws IOException, GeneralSecurityException, TimeoutException {
//
////		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe");
//
//		WebElement element;
//		WebElement courseLink;
//		JavascriptExecutor js1 = (JavascriptExecutor) driver;
//		
//		WebElement message;
//		driver = new ChromeDriver();
//		WebDriverManager.chromedriver().setup();
//		driver.manage().window().maximize();
//		driver.get(getColumnRow(1, 1));
//		System.out.println("Chrome Browser is Launched");
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//}
	 // Locators for the sign-in form
	
//    private static By usernameField = By.id("email");
//    private static By passwordField = By.id("password");
//    private static By signInButton = By.xpath("//button[contains(@class,'signin_bt_signup')]");
//    private By errorMessage = By.id("errorMessage");
	
    public static void implicitWait(){
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
    
	 // Methods to interact with the sign-in page elements
    public static void enterUsername(String username) {
    	
        WebElement usernameElement = driver.findElement(By.id(lo.usernameField));
        usernameElement.clear();
        usernameElement.sendKeys(username);
    }

    public static void enterPassword(String password) {
        WebElement passwordElement = driver.findElement(By.id(lo.passwordField));
        passwordElement.clear();
        passwordElement.sendKeys(password);
    }

    public static void clickSignIn() {
        WebElement signInBtn = driver.findElement(By.xpath(lo.signInButton));
        signInBtn.click();
    }

//    public String getErrorMessage() {
//        WebElement errorElement = driver.findElement(errorMessage);
//        return errorElement.getText();
//    }

    // Method to perform sign-in action
    @Test
    public static void signIn(String username, String password) {
    	implicitWait();
        enterUsername(username);
        enterPassword(password);
        clickSignIn();
    }
}