package PageFactory;

public class IMSLocator {
   
	
	//ims SignIn Locator
	public static String usernameField = "email";
	public static String passwordField = "password";
	public static String signInButton = "//button[contains(@class,'signin_bt_signup')]";
	public static String errorMessage = "errorMessage";
	



}
