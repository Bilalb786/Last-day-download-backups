package StepDefinition;

import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

public class TestRunnerClass {

//	public static void main(String[] args) {
//		TestNG testng = new TestNG();
//
//		// Add the TestNG XML suite file to run
//		testng.setTestSuites(java.util.Collections
//				.singletonList("C:\\Users\\Bilal Hussain\\eclipse-workspace\\IMS_Items_Banking\\testng.xml"));
//
//		// Run the tests
//		testng.run();
//	}
	public static void main(String[] args) {
        TestNG testng = new TestNG();
        
     // Get the project directory dynamically
        String projectPath = System.getProperty("user.dir");

        // Construct the path to the TestNG XML file dynamically
        String testNGSuitePath = projectPath + "\\testng.xml";
        
        List<String> suites = new ArrayList<String>();
        suites.add(testNGSuitePath); // Path to your TestNG suite XML file
        
        testng.setTestSuites(suites);
        testng.run();
    }
}
