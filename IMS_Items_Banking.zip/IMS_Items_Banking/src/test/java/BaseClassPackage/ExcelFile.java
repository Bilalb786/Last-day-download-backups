package BaseClassPackage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ExcelFile {
    public static Sheet ExcelWSheet;
    public static Workbook ExcelWBook;
    public static Cell Cell;
    public static Row Row;
    public static String excel_Path = null;

    public static void setExcelFile(String filePath, String tabName) {
        try {
            excel_Path = filePath;
            FileInputStream inputStream = new FileInputStream(new File(filePath));
            ExcelWBook = getWorkbook(inputStream, filePath);
            ExcelWSheet = setTabName(tabName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Sheet setTabName(String tabName) {
        try {
            ExcelWSheet = ExcelWBook.getSheet(tabName);
        } catch (Exception e) {
            throw (e);
        }
        return ExcelWSheet;
    }

    public static String getCellData(int RowNum, int ColNum) {
        try {
            DataFormatter df = new DataFormatter();
            Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
            return df.formatCellValue(Cell);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static void setCellData(String Result, int RowNum, int ColNum) {
        try {
            Row = ExcelWSheet.getRow(RowNum);
            if (Row == null) {
                Row = ExcelWSheet.createRow(RowNum);
            }
            Cell = Row.getCell(ColNum);
            if (Cell == null) {
                Cell = Row.createCell(ColNum);
            }
            Cell.setCellValue(Result);

            try (FileOutputStream fileOut = new FileOutputStream(excel_Path)) {
                ExcelWBook.write(fileOut);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int getRowCount() {
        try {
            return ExcelWSheet.getLastRowNum();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    private static Workbook getWorkbook(FileInputStream inputStream, String excelFilePath) throws IOException {
        try {
            if (excelFilePath.endsWith("xlsx")) {
                return new XSSFWorkbook(inputStream);
            } else if (excelFilePath.endsWith("xls")) {
                return new HSSFWorkbook(inputStream);
            } else {
                throw new IllegalArgumentException("The specified file is not an Excel file");
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }

//    public static void main(String[] args) {
//        try {
//            String excelPath = "/TestData/userConfig.xlsx"; // Replace with your actual path
//            ExcelFile.setExcelFile(System.getProperty("user.dir") + excelPath, "Android");
//            System.out.println(System.getProperty("user.dir"));
//
//            String env = ExcelFile.getCellData(0, 1);
//            String env1 = ExcelFile.getCellData(1, 1);
//            String env2 = ExcelFile.getCellData(2, 1);
//            String env3 = ExcelFile.getCellData(3, 1);
//            String env4 = ExcelFile.getCellData(4, 1);
//
//            System.out.println(env + env1 + env2 + env3+env4);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
    
//    public static void main(String[] args) {
////        String filePath = "C:\\Users\\Mohammed Abubacker s\\eclipse-workspace\\ActivityCL\\TestData\\userConfig.xlsx";
//        String excelPath = "/TestData/userConfig.xlsx"; 
//        String filePath = System.getProperty("user.dir") +excelPath;
//        String sheetName = "Round1"; // Change this to your actual sheet name
//
//        try {
//            // Load the Excel file
//            FileInputStream file = new FileInputStream(new File(filePath));
//            Workbook workbook = WorkbookFactory.create(file);
//            Sheet sheet = workbook.getSheet(sheetName);
//            
//            if (sheet == null) {
//                System.out.println("Sheet not found");
//                return;
//            }
//
//            // Initialize a counter for non-empty cells in column B (index 1, as it's zero-based)
//            int rowCount = 0;
//            for (Row row : sheet) {
//                Cell cell = row.getCell(1); // Column B (index 1)
//                if (cell != null && cell.getCellType() != CellType.BLANK) {
//                    rowCount++;
//                }
//            }
//
//            System.out.println("Total non-empty cells in column B: " + rowCount);
//
//            // Close resources
//            file.close();
//            workbook.close();
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
    // Method to write a single string value to Excel in a specific row and column C
    public static void writeSingleValueToExcel(String filePath, String sheetName, int rowNumber, String value) {
        try {
            // Load the Excel file
            FileInputStream file = new FileInputStream(new File(filePath));
            Workbook workbook = WorkbookFactory.create(file);
            Sheet sheet = workbook.getSheet(sheetName);
            
            if (sheet == null) {
                System.out.println("Sheet not found");
                file.close();
                return;
            }

            // Access the specified row, or create it if it doesn't exist
            Row row = sheet.getRow(rowNumber);
            if (row == null) {
                row = sheet.createRow(rowNumber); // Create row if it doesn't exist
            }

            // Access column C (index 2) and write the value, or create the cell if it doesn't exist
            Cell cell = row.getCell(2); // Column C (index 2)
            if (cell == null) {
                cell = row.createCell(2); // Create cell if it doesn't exist
            }

            // Write the value into column C
            cell.setCellValue(value);

            // Close the input stream
            file.close();

            // Write the changes back to the Excel file
            FileOutputStream outFile = new FileOutputStream(new File(filePath));
            workbook.write(outFile);

            // Close the output stream and workbook
            outFile.close();
            workbook.close();

            System.out.println("Data written successfully to Excel!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // Example of how to call the method
    public static void main(String[] args) { 
    	String excelPath = "/TestData/userConfig.xlsx"; 
  String filePath = System.getProperty("user.dir") +excelPath;
        String sheetName = "Round1";
        int rowNumber = 1;        // The row index (e.g., 0 for the first row)
        String value = "Your String Valuedsfs"; // The value you want to write to column C

        // Call the method to write a single string value
        writeSingleValueToExcel(filePath, sheetName, rowNumber, value);
    }
}
